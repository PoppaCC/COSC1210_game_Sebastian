# COSC1210_game_Sebastian
Escape the Simulation
In this game you are attempting to escape the simulation by deactivating computers and avoiding enemies. Deactivate 4 computers without hitting an enemy and you will be freed from the simulation.
Run The_Simulation.ipynb
Esc to close objective counter, Arrow keys to move around, Esc to close the game.

├── /The_Simulation/
│   └── The_Simulation.ipynb
│   └── Simulated_Functions.py
│   └── Configure_The_Simulation.py
├── /Drafts/
│   └── New_Features_and_Design.zip
|   └── Basic_Working_Game(Old).zip
├── /Assets/
│   └── character2.png.png
│   └── goose.png
│   └── Tree.png
|   └── Music_For_Game.mp3
├── README.md
├── (There will also be pycache, workspace, and gitattributes files)
